"""Generate a link-only community news digest from public RSS headlines."""
import json, urllib.request, urllib.parse, xml.etree.ElementTree as ET, pathlib, datetime, email.utils
query=urllib.parse.quote('"GTA 6" OR "GTA VI"')
url=f'https://news.google.com/rss/search?q={query}&hl=fr&gl=FR&ceid=FR:fr'
req=urllib.request.Request(url,headers={'User-Agent':'VICEVI-FanHub/1.0'})
with urllib.request.urlopen(req,timeout=25) as resp: raw=resp.read(2_000_000)
root=ET.fromstring(raw)
items=[]
for entry in root.findall('./channel/item'):
    title=(entry.findtext('title') or '').strip()
    link=(entry.findtext('link') or '').strip()
    source=(entry.findtext('source') or '').strip()
    pub=(entry.findtext('pubDate') or '').strip()
    if not title or not link.startswith('https://'):continue
    try: date=email.utils.parsedate_to_datetime(pub).date().isoformat()
    except Exception: date=''
    items.append({'title':title[:180],'url':link,'source':source[:80],'date':date})
    if len(items)>=12:break
path=pathlib.Path(__file__).resolve().parents[1]/'data'/'news.json'
path.write_text(json.dumps({'updated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'items':items},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
